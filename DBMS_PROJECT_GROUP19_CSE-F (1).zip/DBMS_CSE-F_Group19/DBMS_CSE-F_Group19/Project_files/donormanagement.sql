create database bbms;
use bbms;
create table donorsss(donorId int(10)primary key,name varchar(100),fatherName varchar(100),motherName varchar(100),DOB varchar(20),MobileNo varchar(10),gender varchar(10),email varchar(100),bloodGroup varchar(10),city varchar(100),address varchar(200));
desc donorsss;
create table stock(bloodGroup varchar(20), units int(10));
insert into stock values('A+','0');
insert into stock values('A-','0');
insert into stock values('B+','0');
insert into stock values('B-','0');
insert into stock values('O+','0');
insert into stock values('O-','0');
insert into stock values('AB+','0');
insert into stock values('AB-','0');
select *from stock;

